<?php $__env->startSection('title'); ?>
	<?php echo e($job->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	 <div class="page-inside page-single">
         <section>
             
           <div class="wrap row">
                <div class="section-title row">                    
                    <h3 class="col s6"><?php echo e($job->title); ?></h3>
                    <p class="social col s6" style="text-align: center;">
                      <a href="#"><i class="ti-facebook"></i></a> <a href="#"><i class="ti-twitter"></i></a> <a href="#"><i class="ti-googleplus"></i></a>
                    </p>
                </div>            
                <div class="section-content">
                    <div class="row">
                        <div class="s12 m8 col">
                            <p>Salary: <?php echo e($job->salary); ?></p>                
                            <p>Country: <?php echo e($job->country); ?></p>                
                            <p>Quantity: <?php echo e($job->quantity); ?></p>                
                            <p>Facalities: <?php echo e($job->facilities); ?></p>
                            <p>Cost: <?php echo e($job->cost); ?></p>
                            <p>Duty Hours: <?php echo e($job->duty_hours); ?></p>
                            <p>Requirements: <?php echo e($job->requirement); ?></p>

                        </div>
                        <div class="s12 m4 col">
                            <?php if($job->featured): ?>
                                <div class="company-wrap row">
                                    <div class="img-wrap">
                                        <img src="" alt="">
                                    </div>
                                    <div class="text-wrap">                                    
                                        <h5><a href="#"><?php echo e($job->company->name); ?></a></h5>
                                        <p>Address: <?php echo e($job->company->contacts->address); ?></p>
                                        <a href="<?php echo e(url('/company/'.$job->company->slug)); ?>" class="right">View more</a>
                                    </div>  
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <p>Description: <?php echo e($job->description); ?></p>


                    </div>
                    <div class="row">
                        <div class="col s12 m6">
                            
                        </div>
                        <div class="col s12 m6">
                            <button class="btn waves-effect">Apply Now</button>
                        </div>
                    </div>
                                  
                </div>

            </div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>