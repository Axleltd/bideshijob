
		<div class="col s12 m6">
			<?php echo Form::label('email','Company Email:'); ?>	
			<?php echo Form::text('email',(isset($company->contacts->email)? $company->contacts->email:old('email'))); ?>	
			<?php if(count($errors->get('email')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>	

		<div class="col s12 m6">
			<?php echo Form::label('website_link','Company Website:'); ?>	
			<?php echo Form::text('website_link',(isset($company->contacts->website_link)? $company->contacts->website_link:old('website_link'))); ?>

			<?php if(count($errors->get('website_link')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('website_link'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>	
		</div>
		
		<div class="col s12 m6">
			<?php echo Form::label('facebook_link','Company Facebook:'); ?>	
			<?php echo Form::text('facebook_link',(isset($company->contacts->socialMedia->facebook)? $company->contacts->socialMedia->facebook:null)); ?>			
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('twitter_link','Company Twitter:'); ?>		
			<?php echo Form::text('twitter_link',(isset($company->contacts->socialMedia->twitter)? $company->contacts->socialMedia->twitter:null)); ?>

		</div>	
		<div class="form-group col m6 s12 ">    
		    <?php echo Form::label('address',"Address", ['class' => 'control-label']); ?>

		    <?php echo Form::text('address',(isset($company->contacts->address)? $company->contacts->address:old('address')),['class' => 'form-control']); ?>

		    <?php if(count($errors->get('address')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('address'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>
		    <div id="map" style="height:300px !important; width:100%;"></div>
		</div>		

	    <div class="form-group col m6 s12">
	        <?php echo Form::label('country','Country',['class' => 'control-label']); ?>

	        <?php echo Form::text('country',(isset($company->contacts->country)? $company->contacts->country:old('country')),['class' => 'form-control']); ?>

	        <?php if(count($errors->get('country')) > 0): ?>
	        <div class="alert alert-danger">
	            <ul>
	                <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                    <li><?php echo e($error); ?></li>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	            </ul>
	        </div>
	        <?php endif; ?>
	    </div>
    
	    <?php echo Form::hidden('latitude',1,['id'=>'latitude']); ?>

	    <?php echo Form::hidden('longitude',1,['id'=>'longitude']); ?>

	
	</div>
</div>
<?php $__env->startPush('script'); ?>
<script>
	jQuery(document).ready(function($) {
		$('#country').autocomplete({
				data:{
				  <?php echo $__env->make('company._countryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			}
		});
		
	});
</script>
<?php $__env->stopPush(); ?>
