<?php $__env->startSection('title'); ?>
FAQ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>FAQ</h1>	
	
	<?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<div class="col s12 m12">	
				<p>Question:<?php echo e($faq->question); ?></p>
				<p>Answer: <?php echo e($faq->answer); ?></p>								
			</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>