<?php $__env->startSection('content'); ?>

  <h1>'<?php echo e($user->name); ?>' Roles</h1>
  <hr/>

  <?php echo Form::model($user, [ 'route' => [ 'watchtower.user.role.update', $user->id ], 'class' => 'form-horizontal']); ?>


  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="panel panel-primary">
        <div class="panel-heading clearfix">
          <h2 class="panel-title"><i class="fa fa-lg fa-users"></i> Current Roles <small>(<?php echo e($roles->count()); ?>)</small></h2>
        </div>
        
        <div class="panel-body">
          <?php $__empty_1 = true; $__currentLoopData = $roles->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-2 col-sm-3 col-xs-4">
            <label class="checkbox-inline" title="<?php echo e($r->id); ?>">
              <input type="checkbox" name="ids[]" value="<?php echo e($r->id); ?>" checked=""> <?php echo e($r->name); ?>

              <?php if($r->special == 'all-access'): ?>
                <i class="fa fa-star text-success"></i> 
              <?php elseif($r->special == 'no-access'): ?>
                <i class="fa fa-ban text-danger"></i> 
              <?php endif; ?>
            </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
            <span class="text-warning"><i class="fa fa-warning text-warning"></i> This user does not have any defined roles.</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="panel panel-primary">
        <div class="panel-heading clearfix">
          <h2 class="panel-title">
          <i class="fa fa-users"></i> Available Roles <small>(<?php echo e($available_roles->count()); ?>)</small></h2>
        </div>
        
        <div class="panel-body">
          <?php $__empty_1 = true; $__currentLoopData = $available_roles->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-2 col-sm-3 col-xs-4">
            <label class="checkbox-inline" title="<?php echo e($ar->id); ?>">
              <input type="checkbox" name="ids[]" value="<?php echo e($ar->id); ?>"> <?php echo e($ar->name); ?>

              <?php if($ar->special == 'all-access'): ?>
                <i class="fa fa-star text-success"></i> 
              <?php elseif($ar->special == 'no-access'): ?>
                <i class="fa fa-ban text-danger"></i> 
              <?php endif; ?>
            </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
            <span class="text-danger"><i class="fa fa-warning text-danger"></i> There aren't any available roles.</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

   <div class="form-group">
      <div class="col-sm-3">
          <?php echo Form::submit('Update Roles', ['class' => 'btn btn-primary form-control']); ?>

      </div>
      <div class="col-sm-9">
        <button class="btn btn-info pull-right" type="button" data-toggle="collapse" data-target="#collapsePermissions" aria-expanded="false" aria-controls="collapsePermissions">
          Toggle Permissions
        </button>
      </div>
  </div>

  <?php echo Form::close(); ?>


  <div class="row panel-collapse collapse" id="collapsePermissions">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="panel panel-info">
        <div class="panel-heading clearfix">
          <h2 class="panel-title"><i class="fa fa-key"></i> <?php echo e($user->name); ?>'s Permissions (from current roles)</small></h2>
        </div>
        
        <div class="panel-body">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <ul class="list-unstyled">
              <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prole): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <li><strong><?php echo e($prole->name); ?></strong></li>
                <ul>
                  <?php if($prole->special == 'all-access'): ?>
                    <li><i class="fa fa-fw fa-star text-success"></i> All Access</li>
                  <?php elseif($prole->special == 'no-access'): ?>
                    <li><i class="fa fa-fw fa-ban text-danger"></i> No Access</li>
                  <?php else: ?>
                    <?php $__empty_2 = true; $__currentLoopData = $prole->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_2 = false; ?>
                      <li><?php echo e($p->name); ?> <em>(<?php echo e($p->slug); ?>)</em></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_2): ?>
                      <li>This role has no defined permissions</li>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <span class="text-danger"><i class="fa fa-warning text-danger"></i> There are no permissions defined for this user.</span>
              <?php endif; ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('watchtower.views.layouts.master'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>