<?php $__env->startSection('title'); ?>
Homepage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="page-wrap">
  <section class="banner">
    <div class="bg-div">
      <div class="particle-div"></div>
    </div>
    <div class="content-div">
      <div class="search-box wow fadeIn">
        <?php echo Form::open([
                'action' => '\App\Http\Controllers\SearchController@allSearch','method'=>'get']); ?>

          <input type="text" class="title" name="title" placeholder="Job / Training">
          <input type="text" class="location" name="address" placeholder="country">
          <button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
          <?php $__env->startPush('script'); ?>
            <script>
              jQuery(document).ready(function($) {
                $('.location').autocomplete({
                    data:{
                      <?php echo $__env->make('company._countryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  }
                });
                
              });
            </script>
          <?php $__env->stopPush(); ?>
        </form>
      </div>

      <div class="subscribe-box">
        <h3 class="wow fadeIn">Subscribe with us</h3>        
        <?php echo Form::open(['action' => 'SubscriberController@store','files' => 'true','method'=>'post']); ?>

          <input type="text" name="name" placeholder="Full Name">
          <input type="email" name="email" placeholder="Email">
          <input type="text" name="contact" placeholder="Contact number">
          <div class="file-field input-field">
            <div class="btn">
              <span>Upload CV</span>
              <input type="file" name="cv">
            </div>
          </div>
          <button type='submit' class="btn wow zoomIn" >Subscribe</button>
        <?php echo Form::close(); ?>

      </div>
    </div>
  </section>

<div id="apply" class="modal">
    <div class="modal-content">
      <h3>Apply for JOB?TRAINING</h3>
      <form action="">
          <input type="text" placeholder="Full Name">
          <input type="text" placeholder="email">
          <input type="text" placeholder="Contact number">
          <div class="file-field input-field">
            <div class="btn">
              <span>Upload CV</span>
              <input type="file">
            </div>
          </div>
          <button class="btn" >Subscribe</button>
        </form>
    </div>
  </div>
  <section class="jobs row">
    <div class="wrap">
      <div class="section-title">
        <h3 class="wow fadeIn">Featured Jobs</h3>
      </div>
    </div>
    <div class="section-content">
      <ul class="lists">
        <?php $__currentLoopData = $job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <?php if($jo->company): ?>
            <li class="wow fadeInUp">
              <div class="wrap row">
                <div class="img-wrap">
                  <img src="<?php echo e(asset('image/'.$jo->company->logo)); ?>" alt="">
                </div>
                <div class="text-wrap">
                  <h5><?php echo e($jo->title); ?></h5>
                  <div class="row">
                    <div class="s6 m4 col"><i class="fa fa-globe"></i><?php echo e($jo->company->contacts->country); ?></div>
                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Salary:<?php echo e($jo->salary); ?></div>
                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Required Number:<?php echo e($jo->quantity); ?></div>
                    <div class="s6 m4 col"><i class="fa fa-globe"></i><?php echo e($jo->facilities); ?></div>
                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Cost:<?php echo e($jo->cost); ?></div>
                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Duty Hour:<?php echo e($jo->duty_hours); ?></div>
                  </div>
                  <div class="row">
                    <p class="social">
                      Share on <a href="#"><i class="ti-facebook"></i></a> <a href="#"><i class="ti-twitter"></i></a> <a href="#"><i class="ti-googleplus"></i></a>
                    </p>
                  </div>
                </div>
                <div class="btn-wrap">
                  <a class="btn waves-effect" href="#<?php echo e($jo->id); ?>">Apply Now</a><br>
                  <a href="<?php echo e(url('company/'.$jo->company->slug.'/job/'.$jo->slug)); ?>">More info</a>
                </div>
              </div>
            </li>

            <div id="<?php echo e($jo->id); ?>" class="modal">
                <div class="modal-content">
                  <h3>Apply for <?php echo e($jo->title); ?></h3>
                  <?php echo Form::open([
                    'action' => '\App\Http\Controllers\ApplicationController@store',
                     'method'=>'post','files' => true]); ?>

                      <input type="text" name="full_name" placeholder="Full Name">
                      <input type="text"  name="email" placeholder="email">
                      <input type="text" name="contact" placeholder="Contact number">
                      <div class="file-field input-field">
                        <div class="btn">
                          <span>Upload CV</span>
                          <input type="file" name="cv">
                        </div>
                      </div>
                      <button type="submit" class="btn" >Apply</button>
                    <?php echo Form::close(); ?>

                </div>
              </div>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </ul>
    </div>
  </section>
  
  <section class="row training">
    <div class="wrap">
      <div class="section-title">
        <h3 class="wow fadeIn">Recent Trainings</h3>
      </div>
      
      <div class="section-content">
        <ul class="lists row">
          <?php $d=0;?>
          <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>            
            <?php if($tr->company): ?>           
            <li class="s12 m6 l4 col wow fadeInUp" data-wow-delay='<?php echo e($d); ?>s'>
              <div class="wrap">
                <div class="img-wrap">
                  <img src="<?php echo e(asset('image/'.$tr->company->logo)); ?>" alt="">
                </div>
                <div class="text-wrap">
                  <h5><?php echo e($tr->title); ?></h5>
                  <p><i class="fa fa-globe"></i><?php echo e($tr->company->contacts->address); ?></p>
                  <p><i class="fa fa-time"></i>Duration</p>
                  <p><?php echo e($tr->description); ?></p>
                  <a href="<?php echo e(url('company/'.$tr->company->slug.'/training/'.$tr->slug)); ?>" class="right">More info</a>
                </div>
              </div>
            </li>
            <?php endif; ?>
            <?php $d =$d+0.3;?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
    </div>
  </section>

  <section class="services">
    <div class="wrap row">
      <div class="section-title">
        <h3 class="wow fadIn">Our Services</h3>
      </div>
      <div class="row section-content">
        <div class="s12 m4 col wow fadeInUp">
          <i class="fa fa-umbrella"></i>
          <h4>Insurance</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem modi molestias dolorem harum inventore. Vel!</p>
        </div>
        <div class="s12 m4 col wow fadeInUp">
          <i class="fa fa-user-md"></i>
          <h4>Medical</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem modi molestias dolorem harum inventore. Vel!</p>
        </div>
        <div class="s12 m4 col wow fadeInUp">
          <i class="fa fa-flag"></i>
          <h4>immigration</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem modi molestias dolorem harum inventore. Vel!</p>
        </div>
      </div>
    </div>
  </section>

  <section class="all-lists">
    <div class="wrap row">
      <div class="row">
        <div class="section-title row">
          <h4 class="left">Jobs</h4>
          <a class="right" href="/jobs">view all</a>
        </div>
        <ul>
          <?php $__currentLoopData = $job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($jo->company): ?>
              <li><a href="<?php echo e(url('company/'.$jo->company->slug.'/job/'.$jo->slug)); ?>"><?php echo e($jo->title); ?></a></li>          
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
      <hr>
      <div class="row">
        <div class="section-title row">
          <h4 class="left">Trainings</h4>
          <a class="right" href="/training">view all</a>
        </div>
        <ul>
          <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if($tr->company): ?>
            <li><a href="<?php echo e(url('company/'.$tr->company->slug.'/training/'.$tr->slug)); ?>"><?php echo e($tr->title); ?></a></li>            
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
      <hr>
      <div class="row">
        <div class="section-title row">
          <h4 class="left">Agencies</h4>
          <a class="right" href="/company">view all</a>
        </div>
        <ul>
          <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><a href="<?php echo e(url('company/'.$com->slug)); ?>"><?php echo e($com->name); ?></a></li>          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
    </div>
  </section>

  <section class="footer">
    
  </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>