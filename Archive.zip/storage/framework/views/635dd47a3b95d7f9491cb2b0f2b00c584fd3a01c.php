

<input type="text" class="title" name="title" placeholder="Job / Training">
 <input type="text" class="location" name="country" placeholder="country">
 <?php $__env->startPush('script'); ?>
<script>
	jQuery(document).ready(function($) {
		$('.location').autocomplete({
				data:{
				  <?php echo $__env->make('company._countryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			}
		});
		
	});
</script>
<?php $__env->stopPush(); ?>