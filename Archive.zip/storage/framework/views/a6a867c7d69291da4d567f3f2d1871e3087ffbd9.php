<?php $__env->startSection('title'); ?>
	<?php echo app('translator')->get('site.about'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
	<div class="page-inside page-about">
		<section>
			<div class="wrap row">
				<div class="section-title">
					<h3 class="wow fadeIn"><?php echo app('translator')->get('site.about'); ?></h3>
				</div>				
				<div class="section-content">				
					<?php if($about): ?>
						<img src="<?php echo e(asset('image/about/'.$about->image)); ?>" alt="" width="300" height="300">
						<p><?php echo e($about->content); ?></p>
					<?php endif; ?>					
					
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>