<?php $__env->startSection('title'); ?>
	<?php echo app('translator')->get('site.about'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
	<div class="page-inside page-about">
		<section>
			<div class="wrap row">
				<div class="section-title">
					<h3 class="wow fadeIn"><?php echo app('translator')->get('site.about'); ?></h3>
				</div>
				<div class="section-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui eveniet, molestiae a quae laborum praesentium, quod reprehenderit sed molestias mollitia iste repellendus, perferendis in unde beatae deleniti ipsum maiores incidunt at quia et asperiores! Harum blanditiis iusto eligendi, vel reprehenderit tempora, molestias quas quasi nisi, a ex provident quis, voluptatibus assumenda nobis tempore magni illo modi! Natus molestiae ut dolorem, labore adipisci vel ipsa maiores, veritatis deserunt consequatur earum. Consectetur, ratione dolorem aspernatur. Reprehenderit asperiores est, nesciunt architecto molestiae quos quas, nemo, explicabo dicta laudantium similique cumque repudiandae eius sit fugiat, necessitatibus quibusdam at dolor aliquid. A sapiente ipsam, architecto.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui eveniet, molestiae a quae laborum praesentium, quod reprehenderit sed molestias mollitia iste repellendus, perferendis in unde beatae deleniti ipsum maiores incidunt at quia et asperiores! Harum blanditiis iusto eligendi, vel reprehenderit tempora, molestias quas quasi nisi, a ex provident quis, voluptatibus assumenda nobis tempore magni illo modi! Natus molestiae ut dolorem, labore adipisci vel ipsa maiores, veritatis deserunt consequatur earum. Consectetur, ratione dolorem aspernatur. Reprehenderit asperiores est, nesciunt architecto molestiae quos quas, nemo, explicabo dicta laudantium similique cumque repudiandae eius sit fugiat, necessitatibus quibusdam at dolor aliquid. A sapiente ipsam, architecto.</p>
				</div>
			</div>
		</section>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>