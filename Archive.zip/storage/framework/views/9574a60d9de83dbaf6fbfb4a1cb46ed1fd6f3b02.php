<?php $__env->startSection('content'); ?>

	<div class="section-title">
		<h3>Edit Training</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="/profile/company"><?php echo e($training->company->name); ?></a></li>/
			<li><a href="#">Edit training</a></li>

		</ul>
	</div>

	<div class="section-content">
		<h5>Training Details</h5>

		<div class="row">
			 <?php echo Form::model($training, ['action'=>['\App\Http\Controllers\TrainingController@update',$training->company->slug,$training->slug],'method'=>'PUT']); ?>

				<?php echo $__env->make('training._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
				<button type="submit" class="waves-effect waves-light btn">Continue</button>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>