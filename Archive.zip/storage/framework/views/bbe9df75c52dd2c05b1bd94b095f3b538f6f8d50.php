<?php $__env->startSection('title'); ?>
    Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="page-inside">
	
	<div class="banner">
    <div class="wrap">
        
        <div class="search">
            
            <?php echo Form::open([
                    'action' => '\App\Http\Controllers\SearchController@companySearch','method'=>'get']); ?>

            <?php echo $__env->make('company._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <button class="search-btn" type="submit"><i class="fa fa-search"></i></button>
            <?php echo Form::close(); ?>

        </div>
    </div>
    </div>
    
    <section class="page-content training">
        
        <div class="wrap row">
          <div class="section-title">
            <h3 class="wow fadeIn">All Agencies</h3>
          </div>
          
            <div class="section-content">
                <ul class="lists row">

                        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	                
                            <li class="col s12 m6 l4">
                                <div class="wrap">
                                    <div class="img-wrap">
                                       <img src="<?php echo e(asset('image/'.$com->logo)); ?>" alt="" width="300" height="300">
                                    </div>
                                    <div class="text-wrap">
                                        <a class="float-left h5"><?php echo e($com->name); ?></a>
                                        
                                        <p class="address">
                                            <?php if($com->contacts): ?>
                                                <?php echo e($com->contacts->address); ?>

                                            <?php endif; ?>
                                        </p>
                                             
                                         <a href="<?php echo e(url('company/'.$com->slug)); ?>" class="right">More Info</a>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
                <?php echo e($company->links()); ?>

            </div>
    	</div>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>