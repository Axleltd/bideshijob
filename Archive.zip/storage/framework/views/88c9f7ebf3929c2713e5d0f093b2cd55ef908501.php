<?php $__env->startSection('title'); ?>
	User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="alluser">
		<ul>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					
				<li>
					<?php echo e($user->name); ?>

					<?php echo Form::model($user, ['action'=>['\App\Http\Controllers\admin\UserController@suspend',$user->id],'method'=>'PUT']); ?>


                 		<button type="submit" class="waves-effect waves-light btn">Suspend</button>
					<?php echo Form::close(); ?>

					<?php echo Form::model($user, ['action'=>['\App\Http\Controllers\admin\UserController@destroy',$user->id],'method'=>'DELETE']); ?>

                 		<button type="submit" class="waves-effect waves-light btn">Delete</button>
					<?php echo Form::close(); ?>


				</li>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>