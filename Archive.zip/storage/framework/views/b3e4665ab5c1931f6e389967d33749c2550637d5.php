<?php $__env->startSection('content'); ?>
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<div class="section-title">
		<h3>All Jobs</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">All Jobs</a></li>/

		</ul>
	</div>

	<div class="section-content">		
		
		<ul class="row">
			<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<li class="col s12 m6">
				<div class="card">
					<div class="card-image">
						<img src="<?php echo e(asset('image/'.$job->company->logo)); ?>" alt="">
					</div>
					<span class="card-title">
						<a href="<?php echo e(url('company/'.$job->company_id.'/job/'.$job->id)); ?>"><?php echo e($job->title); ?></a>
					</span>

					<div class="row">
						<div class="col s12 m4">
							<a href="<?php echo e(url('dashboard/job/featured/'.$job->id)); ?>" class="<?php echo e(($job->featured == 1) ?'disabled': null); ?> btn" style="font-size: 12px;">Featured</a>
							
						</div>
						<div class="col s12 m4">
							<a href="<?php echo e(url('dashboard/job/unfeatured/'.$job->id)); ?>" class="<?php echo e(($job->featured == 0) ?'disabled': null); ?> btn" style="font-size: 12px;">UnFeatured</a>
							
						</div>
						<div class="col s12 m4">
							<a href="<?php echo e(url('dashboard/job/delete/'.$job->id)); ?>" class="btn red accent-2" style="font-size: 12px; float: right;">Delete</a>
							
						</div>
					</div>
				</div>
			</li>

				
				
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>