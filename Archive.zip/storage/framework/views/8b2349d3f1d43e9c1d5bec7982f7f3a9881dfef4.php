<?php $__env->startSection('content'); ?>

<div class="section-title">
	<div class="row">
		<h3 class="left">Posts</h3>
	</div>
	<ul class="bread-crumb">
		<li><a href="/profile">Dashboard</a></li>/
		<li><a href="#">All Post</a></li>/
	</ul>
</div>

<div class="company">
	<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<a class="btn right" href="<?php echo e(url('/blog/create')); ?>">Create A Post</a>													
	<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		
		<a target="_blank" href="<?php echo e(url('/blog/'.$post->slug)); ?>"><h3><?php echo e($post->title); ?></h3></a>
		<?php if($post->image): ?>
			<img src="<?php echo e(asset('image/blog/'.$post->image)); ?>" alt="" width="300" height="300">
			<?php else: ?>
				<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" width="300" height="300">
		<?php endif; ?>
		<a href="<?php echo e(url('dashboard/posts/active/'.$post->id)); ?>" class="<?php echo e(($post->status == 1) ?'disabled': null); ?> btn">Active</a>
		<a href="<?php echo e(url('dashboard/posts/suspend/'.$post->id)); ?>" class="<?php echo e(($post->status == 0) ?'disabled': null); ?> btn">Suspend</a>				
		<a href="<?php echo e(url('/blog/'.$post->slug.'/edit')); ?>" class="btn">Edit</a>			
		<?php echo Form::model($post,[
	                'action' => ['\App\Http\Controllers\admin\PostsController@destroy',$post->id],'method'=>'delete']); ?>				
			<button type="submit" class="waves-effect waves-light btn">Delete</button>
	    <?php echo Form::close(); ?>

		

	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>