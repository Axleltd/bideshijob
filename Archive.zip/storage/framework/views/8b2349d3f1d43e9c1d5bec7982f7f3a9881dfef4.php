<?php $__env->startSection('content'); ?>
	<div class="company">
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			
			<a target="_blank" href="<?php echo e(url('/company/'.$com->id)); ?>"><h3><?php echo e($com->name); ?></h3></a>
			<img src="<?php echo e(asset('image/'.$com->logo)); ?>" alt="">
			<a href="<?php echo e(url('dashboard/company/active/'.$com->id)); ?>" class="<?php echo e(($com->status == 1) ?'disabled': null); ?> btn">Active</a>
			<a href="<?php echo e(url('dashboard/company/suspend/'.$com->id)); ?>" class="<?php echo e(($com->status == 0) ?'disabled': null); ?> btn">Suspend</a>			
			<?php echo Form::model($com,[
		                'action' => ['\App\Http\Controllers\admin\CompanyController@destroy',$com->id],'method'=>'delete']); ?>				
				<button type="submit" class="waves-effect waves-light btn">Delete</button>
		    <?php echo Form::close(); ?>

			

		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>