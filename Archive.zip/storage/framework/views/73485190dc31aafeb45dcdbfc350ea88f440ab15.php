<?php $__env->startSection('content'); ?>

<div class="application">
	<table>
        <thead>
          <tr>
              <th data-field="id">Name</th>
              <th data-field="name">Email</th>
              <th data-field="price">Download CV</th>
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			
			<tr>
				<td><?php echo e($application->full_name); ?></td>
				<td><?php echo e($application->email); ?></td>
				<td><a href="<?php echo e(asset('file/'.$application->file)); ?>" target="_blank">CV</a></td>
			</tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php echo $applications->links(); ?>

        </tbody>
      </table>	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>