<div class="wrap">
    <div class="img-wrap">
      
    </div>
    <div class="text-wrap">
      <h5><?php echo e($post->title); ?></h5>
      <?php if($post->image): ?>
        <img src="<?php echo e(asset('image/blog/'.$post->image)); ?>" alt="" width="300" height="300">
        <?php else: ?>
        <img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" width="300" height="300">
      <?php endif; ?>
      <p><i class="fa fa-globe"></i><?php echo e($post->short_description); ?></p>
      <p><i class="fa fa-time"></i>Duration</p>
      <p><?php echo e($post->description); ?></p>
      <a href="<?php echo e(url('blog/'.$post->slug)); ?>" class="right">Go To</a>
    </div>
</div>