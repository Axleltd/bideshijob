<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.about'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="page-inside">

  <?php if(Request::url() == url('/training')): ?>
    <nav>
        <div class="nav-wrapper row">
            <div class="col s12">
              <a href="/" class="breadcrumb"><?php echo app('translator')->get('site.home'); ?></a>
              <a href="#!" class="breadcrumb"><?php echo app('translator')->get('site.training'); ?></a>
          
           </div>
        </div>
      </nav>
    <?php else: ?>

    <?php if(isset($company) && $company !== 'search'): ?>

      <nav>
        <div class="nav-wrapper row">
            <div class="col s12">
              <a href="/" class="breadcrumb"><?php echo app('translator')->get('site.home'); ?></a>
              <a href="/company/<?php echo e($company->slug); ?>" class="breadcrumb"><?php echo app('translator')->get('site.agencies'); ?></a>
              <a href="/company/<?php echo e($company->slug); ?>/training" class="breadcrumb"><?php echo app('translator')->get('site.agencies'); ?></a>
              
            </div>
          </div>
       </nav>
    <?php endif; ?>
      

  <?php endif; ?>

  <div class="banner">
      <div class="wrap">
	
      	<div class="search">
              <?php echo Form::open([
                      'action' => '\App\Http\Controllers\SearchController@trainingSearch','method'=>'get']); ?>

              <?php echo $__env->make('frontend._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <button type="submit"  class="search-btn"><i class="fa fa-search"></i></button>
              <?php echo Form::close(); ?>		
      	</div>
      </div>
    </div>

		<section class="row training">
    <div class="wrap">
      <?php if(Request::url() == url('/training')): ?>
        <div class="section-title">
          
        <h3>All Training</h3>  
        </div>
      <?php else: ?>
        <?php if(isset($company) && $company != 'search'): ?>
        <div class="section-title">
          
        <h3>Training of <?php echo e($company->name); ?></h3>
        </div>
      <?php else: ?>
        <div class="section-title">
          
        <h3>Search Results</h3>
        </div>
      <?php endif; ?>

      <?php endif; ?>
      
      <div class="section-content">
        <ul class="lists row">
          <?php $d=0;?>
          <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>            
            <?php if($tr->company): ?>           
            <li class="s12 m6 l4 col wow fadeInUp" data-wow-delay='<?php echo e($d); ?>s'>
              <div class="wrap">
                <div class="img-wrap">
                  <img src="<?php echo e(asset('image/'.$tr->company->logo)); ?>" alt="">
                </div>
                <div class="text-wrap">
                  <h5><?php echo e($tr->title); ?></h5>
                  <p><i class="fa fa-globe"></i><?php echo e($tr->country); ?></p>
                  <p><i class="fa fa-time"></i>Duration</p>
                  <p><?php echo e($tr->description); ?></p>
                  <a href="<?php echo e(url('company/'.$tr->company->slug.'/training/'.$tr->slug)); ?>" class="right">More info</a>
                </div>
              </div>
            </li>
            <?php endif; ?>
            <?php $d =$d+0.3;?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
    </div>
  </section>
        </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>