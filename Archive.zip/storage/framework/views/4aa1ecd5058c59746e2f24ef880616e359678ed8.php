<?php $__env->startSection('title'); ?>
    All Blog 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="page-inside page-blog">


  <nav>
      <div class="nav-wrapper row">
          <div class="col s12">
            <a href="/" class="breadcrumb"><?php echo app('translator')->get('site.home'); ?></a>
            <a href="#!" class="breadcrumb"><?php echo app('translator')->get('site.blog'); ?></a>
        
         </div>
      </div>
  </nav>

  <div class="banner">
      <div class="wrap">
	
      	<div class="search">
              <?php echo Form::open([
                      'action' => '\App\Http\Controllers\SearchController@postSearch','method'=>'get']); ?>

              <input type="text" name="title" placeholder="Post Name">
              <button type="submit"  class="search-btn"><i class="fa fa-search"></i></button>
              <?php echo Form::close(); ?>		
      	</div>
      </div>
    </div>

		<section class="row training">
    <div class="wrap">
        <div class="section-title">
          
        <h3>All Posts</h3>
        </div>
      
      <div class="section-content">
        <ul class="lists row">
          <?php $d=0;?>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>            
                 
            <li class="s12 m6 l4 col wow fadeInUp" data-wow-delay='<?php echo e($d); ?>s'>
              <?php echo $__env->make('post._indexPost', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </li>
   
            <?php $d =$d+0.3;?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
        <?php echo $posts->links(); ?>

      </div>
    </div>
  </section>
        </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>