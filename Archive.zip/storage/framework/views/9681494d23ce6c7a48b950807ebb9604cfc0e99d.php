<?php $__env->startSection('title'); ?>
	Job
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="section-title">
		<h3>All jobs</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">My Job</a></li>/			

		</ul>
	</div>

	<div class="section-content">		
		
		<div class="row">
			<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php if(!count($jobs)>0): ?>
				<h5>You have not created a job yet!</h5>
				<a class="btn" href="<?php echo e(url('/profile/company/')); ?>">Create A New Job</a>
			<?php else: ?>
			<ul>
				<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					
					<li class="col s12 m4">
						<div class="card">
							<div class="card-image">
								<img src="<?php echo e(asset('image/'.$job->company->logo)); ?>" alt="">
							</div>
							
								<span class="card-title"><a href="<?php echo e(url('/company/'.$job->company->slug.'/job/'.$job->slug)); ?>"><?php echo e($job->title); ?></a></span>

								
							
								
						</div>
					</li>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>			
			</ul>
		<?php endif; ?>
		</div>	
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>