<?php $__env->startSection('title'); ?>
	Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


	<div class="section-title">
		<div class="row">
			<h3 class="left">Profile</h3>
			<div class="right">
				<?php if(!(count($profile)>0)): ?>
				
					<a  class="btn" href="<?php echo e(url('/profile/user/create')); ?>">Create Profile</a>
				
				<?php endif; ?>
			</div>
		</div>
		<ul class="bread-crumb">
			<li><a href="">Dashboard</a></li>/
			<li><a href="">Profile</a></li>/
		</ul>
	</div>

	<div class="section-content">

		<div class="row">
	
			<div class="user col s12 m6">
				<?php if(count($profile)>0): ?>
					<?php if($profile->logo): ?>
						<img src="<?php echo e(asset('image/profile/'.$profile->logo)); ?>" alt="">
					<?php else: ?>
						<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="">				
					<?php endif; ?>
					<p><?php echo e($profile->user->email); ?></p>							
				<?php else: ?>
					<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="">
					<p><?php echo e(Auth::user()->email); ?></p>
				<?php endif; ?>	

				<ul>
						<?php if(count($profile)>0): ?>
							<li><a href="<?php echo e(url('/profile/user/'.$profile->id.'/edit')); ?>">Edit Profile</a></li>
						<?php else: ?>
							<li><a href="<?php echo e(url('/profile/user/create')); ?>">Create Profile</a></li>
						<?php endif; ?>			
				</ul>		
			</div>

			<div class="info col s12 m6">
				<?php if(!(count($profile)>0)): ?>
					<h5>No Profile Details. <a href="<?php echo e(url('/profile/user/create')); ?>">Click here</a> to create a profile</h5>
				<?php else: ?>
					<div class="detail">
						<p>First Name: <?php echo e($profile->first_name); ?></p>
						<p>Last Name: <?php echo e($profile->last_name); ?></p>
						<p>Country: <?php echo e($profile->country); ?>

						</p>
						<p>Phone: <a href="tel:<?php echo e($profile->phone); ?>"><?php echo e($profile->phone); ?></a>
						</p>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>