    <?php if( Shinobi::can( config('watchtower.acl.'.$acl.'.search', false)) ): ?>
    <!-- search bar -->    
    <?php echo Form::open(['method'=>'get','route'=> [ $search_route ], 'style' => 'display:inline']); ?>

    <div class="input-group">
      <input type="search" class="form-control input-sm" name="search_value" placeholder="Search for...">
      <span class="input-group-btn">
        <button class="btn btn-default btn-sm" type="submit"><i class="fa fa-fw fa-search"></i></button>
      </span>
    </div>
    <div class="text-muted">
      <em>Found <?php echo e($items->total()); ?> <?php echo e(str_plural('record', $items->count() )); ?>.
      <?php if(session()->has('search_value')): ?>
        Filter : "<?php echo e(session('search_value')); ?>" <a href="<?php echo e(route( $search_route )); ?>">[ Clear Filter ]</a>
      <?php endif; ?>
      </em>
    </div>
    <?php echo Form::close(); ?>

    <?php endif; ?>