<?php $__env->startSection('content'); ?>

<div class="application">
	<table>
        <thead>
          <tr>
              <th data-field="name">Name</th>
              <th data-field="email">Email</th>
              <th data-field="message">Message</th>              
              <th data-field="message">Link</th>              
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>			
            <?php if($notification->data['for'] == 'admin'): ?>
          		<tr>          
          			<td><?php echo e($notification->notifiable->name); ?></td>
          			<td><?php echo e($notification->notifiable->email); ?></td>
          			<td><?php echo e($notification->data['message']); ?></td>				
          			<td><a href="/dashboard/<?php echo e($notification->data['name']); ?>"><?php echo e($notification->data['name']); ?></a></td>				
          		</tr>
             <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>          
        </tbody>
      </table>	
      <?php echo $notifications->links(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>