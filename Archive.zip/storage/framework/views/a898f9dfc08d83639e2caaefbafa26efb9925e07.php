<?php $__env->startSection('content'); ?>
	 <?php echo Form::open([
                'action' => '\App\Http\Controllers\Company\CompanyController@store',
                 'method'=>'post','files' => true]); ?>

		<?php echo $__env->make('admin.company._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make('admin.company._contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<button type="submit" class="waves-effect waves-light btn">Continue</button>
	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>