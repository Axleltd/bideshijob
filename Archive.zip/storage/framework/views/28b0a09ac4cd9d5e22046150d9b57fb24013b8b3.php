
	<div class="user col s12 m5">
		<div class="form-group row">
		    <?php echo Form::label('logo', 'Logo:', ['class' => 'control-label']); ?>

		    <?php if(isset($profile->logo)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="logo" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/profile/'.$profile->logo)); ?>"
		                     alt="<?php echo e($profile->logo); ?>" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>
		    <div class="file-field input-field">
		      <div class="btn">
		        <span>Logo</span>
		        <?php echo Form::file('logo', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		      </div>
		     </div>
		        
		        <?php if(count($errors->get('logo')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('logo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>			
		</div>

		<div class="row">
			<?php if(isset($profile)): ?>
				<p>Name: <?php echo e($profile->user->name); ?></p>
				<p>Email: <a href="mailto:<?php echo e($profile->user->email); ?>"><?php echo e($profile->user->email); ?></a></p>
			<?php endif; ?>
		</div>
	</div>

	<div class="info col s12 m7">
		<div class="row">
			<div class="col s12 m6">
				<?php echo Form::label('first_name','First name:'); ?>	
				<?php echo Form::text('first_name',old('first_name')); ?>	
				<?php if(count($errors->get('first_name')) > 0): ?>
			        <div class="alert alert-danger">
			            <ul>
			                <?php $__currentLoopData = $errors->get('first_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			    <?php endif; ?>		
			</div>
			<div class="col s12 m6">
				<?php echo Form::label('last_name','Last name:'); ?>	
				<?php echo Form::text('last_name',old('last_name')); ?>	
				<?php if(count($errors->get('last_name')) > 0): ?>
			        <div class="alert alert-danger">
			            <ul>
			                <?php $__currentLoopData = $errors->get('last_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			    <?php endif; ?>		
			</div>
			<div class="col s12 m6">
				<?php echo Form::label('country','Country:'); ?>	
				<?php echo Form::text('country',old('country')); ?>	
				<?php if(count($errors->get('country')) > 0): ?>
			        <div class="alert alert-danger">
			            <ul>
			                <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			    <?php endif; ?>		
			</div>
			<div class="col s12 m6">
				<?php echo Form::label('phone','Phone:'); ?>	
				<?php echo Form::text('phone',old('phone')); ?>	
				<?php if(count($errors->get('phone')) > 0): ?>
			        <div class="alert alert-danger">
			            <ul>
			                <?php $__currentLoopData = $errors->get('phone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			    <?php endif; ?>		
			</div>
		</div>
	</div>

<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>