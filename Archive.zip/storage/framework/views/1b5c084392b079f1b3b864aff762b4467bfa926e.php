<?php $__env->startSection('content'); ?>

      <div class="alert alert-danger lead">
        <i class="fa fa-exclamation-triangle fa-1x"></i> You are not permitted to <?php echo e($message); ?>.
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('watchtower.views.layouts.master'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>