<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Bideshi')); ?> | <?php echo $__env->yieldContent('title'); ?> </title>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/materialize.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('stylesheets/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('stylesheets/font-awesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('stylesheets/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('stylesheets/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('stylesheets/screen.css')); ?>">
    
</head>
<body>
    <div id="app">
        
        <header class="header">
          <div class="logo-div">
            <a href="/"><img src="<?php echo e(asset('images/logo.png')); ?>" alt=""></a>
            <div class="nav-toggle">
              <i class="ti-menu"></i>
            </div>
          </div>
          <ul class="top-nav">
            <?php if(Auth::check()): ?>
              <?php if(Shinobi::isRole('admin')): ?>
                <li><a href="/dashboard"><?php echo app('translator')->get('site.dashboard'); ?></a></li>
              <?php else: ?>
                <li><a href="/profile"><?php echo app('translator')->get('site.dashboard'); ?></a></li>
              <?php endif; ?>
              <li><a href="/logout"><?php echo app('translator')->get('site.logout'); ?></a></li>
            <?php else: ?>
              <li><a href="/login"><?php echo app('translator')->get('site.login'); ?></a></li>
              <li><a href="/register"><?php echo app('translator')->get('site.register'); ?></a></li>

            <?php endif; ?>
              <li><a href="locale/en"><?php echo app('translator')->get('site.english'); ?></a></li>
              <li><a href="locale/np"><?php echo app('translator')->get('site.nepali'); ?></a></li>
            
          </ul>
          <ul class="nav">
            <li><a href="/"><?php echo app('translator')->get('site.home'); ?></a></li>
            <li><a href="/about"><?php echo app('translator')->get('site.about'); ?></a></li>
            <li><a href="/jobs"><?php echo app('translator')->get('site.jobs'); ?></a></li>
            <li><a href="/training"><?php echo app('translator')->get('site.training'); ?></a></li>
            <li><a href="/company"><?php echo app('translator')->get('site.agencies'); ?></a></li>
            <li><a href="/faq"><?php echo app('translator')->get('site.faq'); ?></a></li>
            <li><a href="/contact"><?php echo app('translator')->get('site.contact'); ?></a></li>
          </ul>
        </header>
        <div class="page-wrap">
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer class="footer">
          <div class="row">
            <div class="s12 m4 col">
              <h5><?php echo app('translator')->get('site.contact'); ?></h5>
              <ul class="contacts">
                <li>
                  <i class="ti-map"></i>
                  <p><?php echo app('translator')->get('site.city_address'); ?></p>
                  <p><?php echo app('translator')->get('site.country'); ?></p>
                </li>
                <li>
                  <i class="ti-envelope"></i>
                  <a href="mailto:info@bideshikaam.com">info@bideshikaam.com</a>
                </li>
                <li>
                  <i class="ti-phone"></i>
                  <a href="tel:984651325">984651325</a>
                  <a href="tel:984651325">984651325</a>
                </li>
              </ul>
            </div>
            <div class="s12 m4 col">
              <h5>Help & support</h5>
              <li><a href="/faq">FAQ</a></li>
              <li><a href="/faq">FAQ</a></li>
              <li><a href="/faq">FAQ</a></li>
              <li><a href="/faq">FAQ</a></li>
            </div>
            <div class="s12 m4 col">
              <h5>Follow Us</h5>
              <ul class="social">
                <li><a href="#"><i class="ti-facebook"></i></a></li>
                <li><a href="#"><i class="ti-facebook"></i></a></li>
                <li><a href="#"><i class="ti-facebook"></i></a></li>
                <li><a href="#"><i class="ti-facebook"></i></a></li>
              </ul>
            </div>
          </div>
          <p class="cp">&copy; All rights reserved </p>
        </footer>
    </div>
    <script src="<?php echo e(asset('js/jquery-3.1.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/materialize.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pace.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/particles.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('script'); ?>

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>

    </script>
    <!-- Scripts -->
    
    <script>
        $(document).ready(function() {
            $('select').material_select();
          });
    </script>
</body>
</html>

