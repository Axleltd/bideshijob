<html>
<head>
	<title>Bideshi Job | <?php echo $__env->yieldContent('title'); ?> </title>
	<link rel="stylesheet" href="<?php echo e(asset('css/materialize.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('stylesheets/screen.css')); ?>">
	<script src="<?php echo e(asset('js/jquery-3.1.0.js')); ?>"></script>
	<script src="<?php echo e(asset('js/materialize.js')); ?>"></script>
</head>
<body>

	<div id="app" class="login-page">
    
    <header class="header">
      <div class="logo-div">
			<a href="/" class="center"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="brand-logo" style="height:65px"></a>
		</div>
	</header>	
	<div class="">
		<?php echo $__env->yieldContent('content'); ?>	
	</div>	
		<div class="footer">
			
		</div>
	</div>
</body>
</html>