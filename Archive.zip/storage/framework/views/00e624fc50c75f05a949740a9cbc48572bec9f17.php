<div class="form">
	<div class="row">
		<div class="col s12 m6">
			<?php echo Form::label('title','Job Title:'); ?>	
			<?php echo Form::text('title',old('title')); ?>

			<?php if(count($errors->get('title')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div>

		<div class="col s12 m6">
			<?php echo Form::label('description','Description:'); ?>

			<?php echo Form::textarea('description',old('description')); ?>

			<?php if(count($errors->get('description')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('categories','categories:'); ?>

			<?php echo Form::text('categories',old('categories')); ?>

			<?php if(count($errors->get('categories')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('categories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('about_job','about job:'); ?>

			<?php echo Form::textarea('about_job',old('about_job')); ?>

			<?php if(count($errors->get('about_job')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('about_job'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div> 
		<div class="col s12 m6">
			<?php echo Form::label('facilities','Facilities:'); ?>

			<?php echo Form::textarea('facilities',old('facilities')); ?>

			<?php if(count($errors->get('facilities')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('facilities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('duties','duties:'); ?>

			<?php echo Form::textarea('duties',old('duties')); ?>

			<?php if(count($errors->get('duties')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('duties'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div>     
		<div class="col s12 m6">
			<?php echo Form::label('salary','Salary :'); ?>	
			<?php echo Form::number('salary',old('salary')); ?>

			<?php if(count($errors->get('salary')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('salary'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>	
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('cost','cost :'); ?>	
			<?php echo Form::number('cost',old('cost')); ?>

			<?php if(count($errors->get('cost')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('cost'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>	
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('overtime','overtime :'); ?>	
			<?php echo Form::number('overtime',old('overtime')); ?>

			<?php if(count($errors->get('overtime')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('overtime'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>	
		</div>   
		<div class="col s12 m6">
			<?php echo Form::label('quantity','quantity :'); ?>	
			<?php echo Form::number('quantity',old('quantity')); ?>

			<?php if(count($errors->get('quantity')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('quantity'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>	
		</div>  
		<div class="col s12 m6">
			<?php echo Form::label('duty_hours','duty_hours :'); ?>	
			<?php echo Form::number('duty_hours',old('duty_hours')); ?>	
			<?php if(count($errors->get('duty_hours')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('duty_hours'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div> 		
		<div class="col s12 m6">
			<?php echo Form::label('requirement','requirements :'); ?>	
			<?php echo Form::textarea('requirement',old('requirement')); ?>	
			<?php if(count($errors->get('requirement')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('requirement'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>
		</div> 
		<div class="col s12 m6">
			<?php echo Form::label('country','Country :'); ?>	
			<?php echo Form::textarea('country',old('country')); ?>

			<?php if(count($errors->get('country')) > 0): ?>
			        <div class="error">
			            <ul>

			                <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			                    <li><?php echo e($error); ?></li>
			                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			            </ul>
			        </div>
			<?php endif; ?>	
		</div>             
	</div>
</div>
