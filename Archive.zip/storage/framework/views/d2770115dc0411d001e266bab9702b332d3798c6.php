<?php $__env->startSection('content'); ?>

    <h1>Users
    <div class="btn-group pull-right" role="group" aria-label="...">    
      <a href="<?php echo e(route('watchtower.user.matrix')); ?>">
      <button type="button" class="btn btn-default">
        <i class="fa fa-th fa-fw"></i> 
        <span class="hidden-xs hidden-sm">User Matrix</span>
      </button></a>

      <a href="<?php echo e(route('watchtower.user.create')); ?>">
      <button type="button" class="btn btn-info">
        <i class="fa fa-plus fa-fw"></i> 
        <span class="hidden-xs hidden-sm">Add New User</span>
      </button></a>
    </div>
    </h1>

    <!-- search bar -->
    <?php echo $__env->make(config('watchtower.views.layouts.search'), [ 'search_route' => 'watchtower.user.index', 'items' => $users, 'acl' => 'user' ] , array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="table">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</th><th>Name</th><th>Actions</th>
                </tr>
            </thead>

            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
               <tr>
                <td><?php echo e($item->id); ?></td>
                
                <td>
                    <a href="<?php echo e(route('watchtower.user.show', $item->id)); ?>"><?php echo e($item->name); ?></a>
                </td>
                
                <td>
                    <?php if( Shinobi::can( config('watchtower.acl.user.role', false)) ): ?>
                    <a href="<?php echo e(route('watchtower.user.role.edit', $item->id)); ?>">
                      <button type="button" class="btn btn-primary btn-xs">
                      <i class="fa fa-users fa-fw"></i> 
                      <span class="hidden-xs hidden-sm">Roles</span>
                      </button></a>
                    <?php endif; ?>

                    <?php if( Shinobi::can( config('watchtower.acl.user.edit', false)) ): ?>
                    <a href="<?php echo e(route('watchtower.user.edit', $item->id)); ?>">
                      <button type="button" class="btn btn-default btn-xs">
                      <i class="fa fa-pencil fa-fw"></i> 
                      <span class="hidden-xs hidden-sm">Update</span>
                      </button></a>
                    <?php endif; ?>


                    <?php if( Shinobi::can( config('watchtower.acl.user.destroy', false)) ): ?>
                    <?php echo Form::open(['method'=>'delete','route'=> ['watchtower.user.destroy',$item->id], 'style' => 'display:inline']); ?>

                      <button type="submit" class="btn btn-danger btn-xs">
                      <i class="fa fa-trash-o fa-lg"></i> 
                      <span class="hidden-xs hidden-sm">Delete</span>
                      </button>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                </td>
               </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <tr><td>There are no users</td></tr>
              <?php endif; ?>

              <!-- pagination -->
              <tfoot>
                <tr>
                 <td colspan="3" class="text-center small">
                  <?php echo $users->render(); ?>

                 </td>
                </tr>
              </tfoot>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('watchtower.views.layouts.master'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>