<?php $__env->startSection('title'); ?>
	<?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-inside">
	
	
  <nav>
      <div class="nav-wrapper row">
          <div class="col s12">
            <a href="/" class="breadcrumb"><?php echo app('translator')->get('site.home'); ?></a>
            <a href="/blog/" class="breadcrumb">Blog</a>
            <a href="#!" class="breadcrumb"><?php echo e($post->title); ?></a>
        
         </div>
      </div>
  </nav>

	<div class="row">	
		<div class="container">
			<h3><?php echo e($post->title); ?></h3>
			<?php if($post->category !== null && $post->category->count() > 0): ?>
			<h3><?php echo e($post->category->name); ?></h3>
			<?php endif; ?>
			<h4><?php echo e($post->published_on); ?></h4>
			<p><small><?php echo $post->short_description; ?></small></p>
			<p>
				<?php echo $post->content; ?>

			</p>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>