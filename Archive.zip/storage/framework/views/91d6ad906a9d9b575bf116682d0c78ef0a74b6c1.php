<?php $__env->startSection('title'); ?>
	Training
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="section-title">
		<h3>All Trainings</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">My Training</a></li>/			

		</ul>
	</div>

	<div class="section-content">		
		
		<div class="row">
			<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php if(!count($trainings)>0): ?>
				<h5>You have not created a Training yet!</h5>
				<a class="btn" href="<?php echo e(url('/profile/company/')); ?>">Create A New Training</a>
			<?php else: ?>
			<ul>
				<?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					
					<li class="col s12 m4">
						<div class="card">
							<div class="card-image">
								<?php if($training->image): ?>
									<img src="<?php echo e(asset('image/training/'.$training->image)); ?>" alt="">
								<?php else: ?>
									<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="">
								<?php endif; ?>
							</div>
							<span class="card-title">
								<a href="<?php echo e(url('/company/'.$training->company->slug.'/training/'.$training->slug)); ?>"><?php echo e($training->title); ?></a>
							</span>
							<a href="<?php echo e(url('/company/'.$training->company->slug.'/training/'.$training->slug.'/edit')); ?>" class="btn">Edit</a>

							<div class="col s12 m4">							
								<?php echo Form::model($training,[
							                'action' => ['\App\Http\Controllers\TrainingController@destroy',$training->id],'method'=>'delete']); ?>				
									<button type="submit" class="waves-effect waves-light red acent-2 btn">Delete</button>
							    <?php echo Form::close(); ?>	
						    </div>						

						
					</li>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>			
			</ul>
		<?php endif; ?>
		</div>	
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>