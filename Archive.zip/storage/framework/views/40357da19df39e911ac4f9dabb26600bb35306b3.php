<?php $__env->startSection('title'); ?>
FAQ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<div class="section-title">
		<div class="row">
			<h3 class="left">FAQ</h3>
			<a href="/dashboard/faq/create" class="btn right">Create New</a>
		</div>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">All FAQ</a></li>/
		</ul>
	</div>	
	<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<div class="col s12 m12">	
				<p>Question:<?php echo e($faq->question); ?></p>
				<p>Answer: <?php echo e($faq->answer); ?></p>
				<p>Status:
					<?php if($faq->status): ?>
						Active
					<?php else: ?>
						Inactive
					<?php endif; ?>	
				</p>
				<hr>				
				<p> <a href="/dashboard/faq/<?php echo e($faq->id); ?>/edit" class="btn">Edit</a></p>
				<p> <a href="/dashboard/faq/active/<?php echo e($faq->id); ?>" class="<?php echo e(($faq->status == 1) ?'disabled': null); ?> btn">Active</a></p>				
				<p> <a href="/dashboard/faq/suspend/<?php echo e($faq->id); ?>" class="<?php echo e(($faq->status == 0) ?'disabled': null); ?> btn">Suspend</a></p>				
				<?php echo Form::model($faq,[
	                'action' => ['\App\Http\Controllers\admin\FAQController@destroy',$faq->id],'method'=>'delete']); ?>				
					<button type="submit" class="waves-effect waves-light btn">Delete</button>
			    <?php echo Form::close(); ?>

			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>