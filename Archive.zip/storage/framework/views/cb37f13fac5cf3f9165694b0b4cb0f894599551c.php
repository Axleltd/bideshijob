<div class="form">
	<div class="row">
		<div class="col s12 m6">
			<?php echo Form::label('name','Company Name:'); ?>	
			<?php echo Form::text('name',old('name')); ?>	
			<?php if(count($errors->get('name')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="col s12 m6">

		   	<?php echo Form::label('logo', 'Logo:', ['class' => 'control-label']); ?>


		    <?php if(isset($company->logo)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="logo" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/'.$company->logo)); ?>"
		                     alt="<?php echo e($company->name); ?>" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>

		    <div class="file-field input-field">
		      <div class="btn">
		        <span>Logo</span>

		        <?php echo Form::file('logo', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		       </div>
		    </div>
		    <?php if(count($errors->get('logo')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('logo'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		

		</div>

		<div class="col s12">
			<?php echo Form::label('description','Description:'); ?>

			<?php echo Form::textarea('description',old('description')); ?>

			<?php if(count($errors->get('description')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
	</div>
</div>

<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>



