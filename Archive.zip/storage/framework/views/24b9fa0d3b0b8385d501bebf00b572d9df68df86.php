<?php $__env->startSection('content'); ?>

	<div class="section-title">
		<h3>Edit Post</h3>
		<ul class="bread-crumb">
			<li><a href="">Dashboard</a></li>/
			<li><a href="">Company Name</a></li>/
			<li><a href="#">Edit Post</a></li>

		</ul>
	</div>

	<div class="section-content">
		<h5>Post Details</h5>

		<div class="row">
			 <?php echo Form::model($post, ['action'=>['\App\Http\Controllers\PostsController@update',$post->slug],'method'=>'PUT','files' => true]); ?>

				<?php echo $__env->make('post._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>				
				<button type="submit" class="waves-effect waves-light btn">Continue</button>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>