<?php $__env->startSection('title'); ?>
Messages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>Messages</h1>	
	
	<?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<div class="col s12 m12" <?php if(!$message->seen): ?> style="background:#ccc"  <?php endif; ?>>	
			<p>Name:<?php echo e($message->name); ?></p>
			<p>Email: <?php echo e($message->email); ?></p>
			<p>Message: <?php echo e($message->messages); ?></p>
			<hr>
			<?php if(Shinobi::isRole('admin')): ?>
			<p> <a href="message/<?php echo e($message->id); ?>/delete" class="btn">Delete</a></p>
			<?php endif; ?>
			<p> <a href="message/<?php echo e($message->id); ?>" class="btn">View</a></p>
			<?php if(!$message->seen): ?>
			<p> <a href="<?php echo e(action('MessageController@markSeen',$message->id)); ?>" class="btn">Mark As Read</a></p>
			<?php else: ?>
			<p> <a href="<?php echo e(action('MessageController@markUnSeen',$message->id)); ?>" class="btn">Mark Unread</a></p>
			<?php endif; ?>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>