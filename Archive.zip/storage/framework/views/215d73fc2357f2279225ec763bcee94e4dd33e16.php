
            <div class="col-lg-3 col-md-6" title="<?php echo e($item['name']); ?>">
                <div class="panel panel-<?php echo e($item['colour']); ?>">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-12">
                                <i class="<?php echo e($item['icon']); ?>"></i>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(route($item['route'])); ?>">
                        <div class="panel-footer">
                            <span class="pull-left"><?php echo e($item['name']); ?></span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>