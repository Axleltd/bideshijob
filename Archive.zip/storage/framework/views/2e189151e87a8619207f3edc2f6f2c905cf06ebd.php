<?php $__env->startSection('content'); ?>

	<div class="section-title">
		<h3>Edit Agency</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="<?php echo e(url('/profile/company')); ?>"><?php echo e($company->name); ?></a></li>/
			<li><a href="#">Edit Agency</a></li>

		</ul>
	</div>

	<div class="section-content">
		<h5>Agency Details</h5>
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			 <?php echo Form::model($company, ['action'=>['\App\Http\Controllers\Company\CompanyController@update',$company->id],'method'=>'PUT','files' => true]); ?>

				<?php echo $__env->make('company._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php echo $__env->make('company._contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
				<button type="submit" class="waves-effect waves-light btn">Continue</button>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>