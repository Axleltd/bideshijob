<?php $__env->startSection('content'); ?>
	<h1>404 Error</h1>
	<a href="<?php echo e(URL::previous()); ?>">Go Back</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>