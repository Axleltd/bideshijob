<div class="form">
	<div class="row">
		<div class="col s12 m6">
			<?php echo Form::label('name','Company Name:'); ?>	
			<?php echo Form::text('name',old('name')); ?>	
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('description','Description:'); ?>

			<?php echo Form::textarea('description',old('description')); ?>

		</div>
		 <div class="file-field input-field">
	      <div class="btn">
	        <span>Logo</span>
	        <?php echo Form::file('logo'); ?>       
	      </div>      
	    </div>    
	</div>
</div>