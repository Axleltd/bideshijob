<?php $__env->startSection('content'); ?>


<div class="section-title">
	<div class="row">
		<h3 class="left">About Us</h3>
	</div>
	<ul class="bread-crumb">
		<li><a href="/profile">Dashboard</a></li>/
		<li><a href="#">About Us</a></li>/
	</ul>
</div>

<div class="section-content">			
	<div class="row">		
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<ul>
			<?php if($about): ?>			
				<li><a href="/dashboard/about/edit" class="btn">Edit</a></li>			
				<?php echo Form::model($about,[
			                'action' => ['\App\Http\Controllers\admin\AboutUsController@destroy',$about->id],'method'=>'delete']); ?>				
					<button type="submit" class="waves-effect waves-light btn red accent-2" >Delete</button>				
			    <?php echo Form::close(); ?>

			    <li><img src="<?php echo e(asset('image/about/'.$about->image)); ?>" alt="" width="300" height="300"></li>
				<li><?php echo $about->content; ?></li>
			<?php else: ?>
				<h5>You have not created about us page</h5>
				<a class="btn" href="<?php echo e(url('/dashboard/about/create')); ?>">Create about us page</a>
			<?php endif; ?>
		</ul>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>