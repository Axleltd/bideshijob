<div class="form">
	<div class="row">
		<div class="col s12 m6">
			<?php echo Form::label('title','Training Title:'); ?>	
			<?php echo Form::text('title',old('title')); ?>	
			<?php if(count($errors->get('title')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="col s12 m6 logo">

		   	<?php echo Form::label('image', 'Image:', ['class' => 'control-label']); ?>


		    <?php if(!empty($training->image)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="logo" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/training/'.$training->image)); ?>"
		                     alt="<?php echo e($training->title); ?>" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>

		    <div class="file-field input-field">
		      <div class="btn">
		        <span>Image</span>

		        <?php echo Form::file('image', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		       </div>
		    </div>
		    <?php if(count($errors->get('image')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		

		</div>
		<div class="col s12 m6">
			<?php echo Form::label('training_description','Description:'); ?>

			<?php echo Form::textarea('training_description',(isset($training->description)? $training->description:old('training_description'))); ?>

			<?php if(count($errors->get('training_description')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('training_description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>		 
		<div class="col s12 m6">
			<?php echo Form::label('categories','Categories:'); ?>

			<?php echo Form::textarea('categories',old('categories')); ?>

			<?php if(count($errors->get('categories')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('categories'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>		 
		<div class="col s12 m6">
			<?php echo Form::label('fees','Fees:'); ?>

			<?php echo Form::text('fees',old('fees')); ?>

			<?php if(count($errors->get('fees')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('fees'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="col s12 m6">
			<?php echo Form::label('from','From:'); ?>

			<?php echo Form::date('from',old('from')); ?>

			<?php if(count($errors->get('from')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('from'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>		 
		<div class="col s12 m6">
			<?php echo Form::label('to','To:'); ?>

			<?php echo Form::date('to',old('to')); ?>

			<?php if(count($errors->get('to')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('to'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>		 
		<div class="col s12 m6">
			<?php echo Form::label('country','Quantity:'); ?>

			<?php echo Form::number('quantity',null,['class' => 'form-control','step'=>'any']); ?>

			<?php if(count($errors->get('quantity')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('quantity'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>

		<div class="col s12 m6">
			<?php echo Form::label('country','Country:'); ?>

			<?php echo Form::text('country',null,['class' => 'form-control','step'=>'any']); ?>

			<?php if(count($errors->get('country')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('country'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>			 			 
</div>


<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>