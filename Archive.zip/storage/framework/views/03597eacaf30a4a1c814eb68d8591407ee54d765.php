<?php $__env->startSection('content'); ?>
	<div class="section-title">
		<div class="row">
			<h3 class="left">Training</h3>			
		</div>
		<ul class="bread-crumb">
			<li><a href="">Dashboard</a></li>/
			<li><a href="">Training</a></li>/
		</ul>
	</div>

	<div class="section-content">

		<div class="row">

			<div class="training">
				<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					
					<a href="<?php echo e(url('company/'.$training->company_id.'/training/'.$training->id)); ?>"><h3><?php echo e($training->title); ?></h3></a>
					<img src="<?php echo e(asset('image/'.$training->company->logo)); ?>" alt="">
					<a href="<?php echo e(url('dashboard/training/featured/'.$training->id)); ?>" class="<?php echo e(($training->featured == 1) ?'disabled': null); ?> btn">Featured</a>
					<a href="<?php echo e(url('dashboard/training/unfeatured/'.$training->id)); ?>" class="<?php echo e(($training->featured == 0) ?'disabled': null); ?> btn">UnFeatured</a>
					<a href="<?php echo e(url('dashboard/training/delete/'.$training->id)); ?>" class="btn">Delete</a>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</div>
		</div>		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>