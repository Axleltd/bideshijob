<?php $__env->startSection('content'); ?>
	<div class="section-title">
		<div class="row">
			<h3 class="left">Training</h3>			
		</div>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">All Training</a></li>/
		</ul>
	</div>

	<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="section-content">

		<ul class="row">
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<li class="col s12 m6">
				<div class="card">
					<div class="card-image">
						<img src="<?php echo e(asset('image/training/'.$training->image)); ?>" alt="">
					</div>
					<span class="card-title">
						<a href="<?php echo e(url('company/'.$training->company_id.'/training/'.$training->id)); ?>"><?php echo e($training->title); ?></a>
					</span>

					<div class="row">
						<div class="col s12 m4">
							<a href="<?php echo e(url('dashboard/training/featured/'.$training->id)); ?>" class="<?php echo e(($training->featured == 1) ?'disabled': null); ?> btn"  style="font-size: 12px;">Featured</a>
							
						</div>
						<div class="col s12 m4">
							<a href="<?php echo e(url('dashboard/training/unfeatured/'.$training->id)); ?>" class="<?php echo e(($training->featured == 0) ?'disabled': null); ?> btn"  style="font-size: 12px;">UnFeatured</a>
							
						</div>
						<div class="col s12 m4">							
							<?php echo Form::model($training,[
						                'action' => ['\App\Http\Controllers\admin\TrainingController@destroy',$training->id],'method'=>'delete']); ?>				
								<button type="submit" class="waves-effect waves-light red acent-2 btn">Delete</button>
						    <?php echo Form::close(); ?>							
							
						</div>
					</div>
				</div>
			</li>

					
					
					
					
					
					

				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</div>		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>