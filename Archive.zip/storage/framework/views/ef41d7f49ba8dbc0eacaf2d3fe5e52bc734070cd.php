<?php $__env->startSection('title'); ?>
	Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="form">
		<?php echo Form::open([
                'action' => '\App\Http\Controllers\ProfileController@store',
                 'method'=>'post','files' => true]); ?>

			<?php echo $__env->make('admin.user._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<button type="submit" class="waves-effect waves-light btn">Create</button>
		<?php echo Form::close(); ?>


	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>