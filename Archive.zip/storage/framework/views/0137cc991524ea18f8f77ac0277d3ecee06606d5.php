<div class="form">
	<div class="row">
		<div class="col s12 m6 input-field">
			<?php echo Form::text('title',old('title')); ?>	
			<?php echo Form::label('title','Post Title:'); ?>	
			<?php if(count($errors->get('title')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<?php if(Shinobi::isRole('admin')): ?>
			<div class="col s12 m6 input-field">
				 <div class="input-field col s12">
				    <select>
	      				<option value="" disabled <?php if(!isset($post)): ?> selected <?php endif; ?>>Choose your option</option>
				      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<option value="<?php echo e($category->id); ?>" 
							<?php if(isset($post) && $post->category_id !== null && $post->category_id == $category->id): ?> 	selected 
							<?php endif; ?>
							><?php echo e($category->name); ?></option>
				      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				    </select>
				    <label>Category</label>
				  </div>
			</div>
		<?php else: ?>
			<?php echo Form::hidden('categoy_id', $categories->id); ?>

		<?php endif; ?>
			<?php if(count($errors->get('slug')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('slug'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="input-field">
		    <?php if(isset($post->image)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="image" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/'.$post->image)); ?>"
		                     alt="<?php echo e($post->title); ?>" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>
		  <div class="file-field input-field">
		  	<div class="btn">
		  		<span>Image</span>
		        <?php echo Form::file('image', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		  	</div>
		  	 <div class="file-path-wrapper">
		        <input class="file-path validate" type="text">
		      </div>
	  	</div>
		        <?php if(count($errors->get('image')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		

		</div>
		<div class="col s12 m6 input-field">
			<?php echo Form::textarea('content',old('content')); ?>	
			<?php echo Form::label('content','Content:'); ?>	
			<?php if(count($errors->get('content')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="col s12 m6 input-field">
			<?php echo Form::textarea('short_description',old('short_description')); ?>	
			<?php echo Form::label('short_description','Description:'); ?>	
			<?php if(count($errors->get('short_description')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('short_description'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		 <!-- Switch -->
		 <div class="input-field col s12 m6 ">
		 	
		      <input type="checkbox" name="published" id="published" <?php if(isset($post) && $post->published == 1): ?>checked="checked" selected <?php endif; ?>>
		 		<label for="published">Published</label>
		    
		 </div>
		  
		<div class="input-field col s12 m6">
			<?php echo Form::label('published_on','Publish On:'); ?>	
			<?php echo Form::date('published_on',old('published_on'),['class'=>'datepicker']); ?>	
			<?php if(count($errors->get('published_on')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('published_on'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
	</div>
</div>
<?php $__env->startPush('script'); ?>
	<script type="text/javascript">
	  $('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 15, // Creates a dropdown of 15 years to control year
	    format: 'yyyy-mm-dd'
	    
	  });

	</script>
<?php $__env->stopPush(); ?>
<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>
