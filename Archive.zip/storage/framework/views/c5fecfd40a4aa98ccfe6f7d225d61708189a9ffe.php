<?php $__env->startSection('content'); ?>

    <h1>Create New User</h1>
    <hr/>

    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                    <?php echo e(csrf_field()); ?>

    
    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <?php echo Form::label('name', 'Name: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>
        <?php echo $errors->first('name', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>

    <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
        <?php echo Form::label('email', 'Email Address: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::text('email', null, ['class' => 'form-control']); ?>

        </div>
        <?php echo $errors->first('email', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>

    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
        <?php echo Form::label('password', 'Password: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-md-6">
            <input type="password" class="form-control" name="password">
            <?php echo $errors->first('password', '<div class="text-danger">:message</div>'); ?>

        </div>
    </div>

    <div class="form-group <?php echo e($errors->has('password_confirmation') ? 'has-error' : ''); ?>">
        <?php echo Form::label('password_confirmation', 'Confirm Password: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-md-6">
            <input type="password" class="form-control" name="password_confirmation">
            <?php echo $errors->first('password_confirmation', '<div class="text-danger">:message</div>'); ?>

        </div>
    </div>

    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create', ['class' => 'btn btn-primary form-control']); ?>

        </div>    
    </div>
    
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('watchtower.views.layouts.master'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>