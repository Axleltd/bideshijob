<?php $__env->startSection('title'); ?>
	Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

		<div class="section-title">
			<h3>Dashboard</h3>
			<p>Hello <?php echo e(Auth::user()->name); ?> Welcome to Dashboard of Bideshikaam.</p>
		</div>

		<div class="section-content">
			<h5>All entries</h5>
			<div class="row">
				<div class="s12 m6 l4 col">
					<div class="card">
						<div class="card-title">Agencies</div>
						<p><?php echo e(count($companies)); ?> Agencies</p>
						<div class="card-action">
							<a href="<?php echo e(url('/profile/company')); ?>">View All</a>
						</div>
					</div> 
				</div>
				<div class="s12 m6 l4 col">
					<div class="card">
						<div class="card-title">Jobs</div>
						<p><?php echo e($job_count); ?> Jobs</p>
						<div class="card-action">
							<a href="<?php echo e(url('/profile/job')); ?>">View All</a>
						</div>
					</div> 
				</div>
				<div class="s12 m6 l4 col">
					<div class="card">
						<div class="card-title">Trainings</div>
						<p><?php echo e($training_count); ?> Trainings</p>
						<div class="card-action">
							<a href="<?php echo e(url('/profile/training')); ?>">View All</a>
						</div>
					</div> 
				</div>
			</div>
		</div>

		<?php if(Shinobi::isRole('admin')): ?>
			<div class="section-content">
				<h5>Edit website</h5>
				<div class="row">
					<div class="col s12 m6 l4">
						<div class="card">
							<div class="card-title">About US</div>
							<p>Information of your organization</p>
							<div class="card-action">
								<a href="">Edit</a>|
								<a href="">View</a>
							</div>
						</div> 
					</div>
					<div class="col s12 m6 l4">
						<div class="card">
							<div class="card-title">FAQ</div>
							<p>Frequently Asked Question</p>
							<div class="card-action">
								<a href="/dashboard/faq">Edit</a>|
								<a href="/dashboard/faq">View</a>
							</div>
						</div> 
					</div>
					<div class="col s12 m6 l4">
						<div class="card">
							<div class="card-title">Blog</div>
							<p>Medical, immigration, insurance posts.</p>
							<div class="card-action">
								<a href="">Edit</a>|
								<a href="">View</a>
							</div>
						</div> 
					</div>
				</div>
			</div>
		<?php endif; ?>











	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>