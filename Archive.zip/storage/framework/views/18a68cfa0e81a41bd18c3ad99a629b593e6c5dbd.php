<div class="form">
	<div class="row">		
		<div class="col s12 m6">

		   	<?php echo Form::label('image', 'Image:', ['class' => 'control-label']); ?>


		    <?php if(isset($about->image)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="logo" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/about/'.$about->image)); ?>"
		                     alt="image" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>

		    <div class="file-field input-field">
		      <div class="btn">
		        <span>Image</span>

		        <?php echo Form::file('image', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		       </div>
		    </div>
		    <?php if(count($errors->get('image')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		

		</div>

		<div class="col s12">
			<?php echo Form::label('content','Content:'); ?>

			<?php echo Form::textarea('content',old('content')); ?>

			<?php if(count($errors->get('content')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
	</div>
</div>

<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>



