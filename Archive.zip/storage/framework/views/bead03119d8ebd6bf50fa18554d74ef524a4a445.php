<?php $__env->startSection('content'); ?>


	<div class="section-title">
		<div class="row">
			<h3 class="left">Profile</h3>
		</div>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">All Company</a></li>/
		</ul>
	</div>

	<div class="section-content">

		<div class="row">
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<ul>
			<?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li class="col m6 s12">
					<div class="card">
						<div class="card-image">
							<img src="<?php echo e(asset('image/'.$com->logo)); ?>" alt="">
						</div>
						<span class="card-title">
							<a target="_blank" href="<?php echo e(url('/company/'.$com->id)); ?>"><?php echo e($com->name); ?></a>
						</span>
						<div class="row">
							<ul>
								<li class="col s12 m4">
									<a href="<?php echo e(url('dashboard/company/active/'.$com->id)); ?>" class="<?php echo e(($com->status == 1) ?'disabled': null); ?> btn">Active</a>
								</li>
								<li class="col s12 m4">
									<a href="<?php echo e(url('dashboard/company/suspend/'.$com->id)); ?>" class="<?php echo e(($com->status == 0) ?'disabled': null); ?> btn">Suspend</a>	
								</li>		
								<li class="col s12 m4">
									<?php echo Form::model($com,[
								                'action' => ['\App\Http\Controllers\admin\CompanyController@destroy',$com->id],'method'=>'delete']); ?>				
										<button type="submit" class="waves-effect waves-light btn">Delete</button>
								    <?php echo Form::close(); ?>

								</li>
							</ul>
						</div>
					</div>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

		</ul>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>