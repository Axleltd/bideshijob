<?php if(Session::has('flash.message')): ?>
    <?php if(Session::has('flash.overlay')): ?>
        <?php echo $__env->make(config('watchtower.views.layouts.modal'), ['modalClass' => 'flash-modal', 'title' => Session::get('flash.title'), 'body' => Session::get('flash.message')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
        <div class="lead alert alert-<?php echo e(Session::get('flash.level')); ?>">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

            <?php echo Session::get('flash.message'); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>