<?php $__env->startSection('title'); ?>
	All Jobs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-inside">

	<?php if(Request::url() == url('/jobs')): ?>
		<nav>
	  		<div class="nav-wrapper row">
	      		<div class="col s12">
	        		<a href="/" class="breadcrumb">Home</a>
	        		<a href="#!" class="breadcrumb">Jobs</a>
	        
	     		 </div>
	    	</div>
	  	</nav>
		<?php else: ?>

		<?php if(isset($company) && $company !== 'search'): ?>

			<nav>
				<div class="nav-wrapper row">
			      <div class="col s12">
			        <a href="/" class="breadcrumb">Home</a>
			        <a href="/company/<?php echo e($company->id); ?>" class="breadcrumb">Company</a>
			        <a href="/company/<?php echo e($company->id); ?>/job" class="breadcrumb">Job</a>
			        
			      </div>
			    </div>
			 </nav>
		<?php endif; ?>
			

	<?php endif; ?>
	<div class="banner">
    	<div class="wrap">
        
			<div class="search">
				 <?php echo Form::open([
                	'action' => '\App\Http\Controllers\SearchController@jobSearch','method'=>'get']); ?>

			        <?php echo $__env->make('frontend._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			        <button type="submit"  class="search-btn"><i class="fa fa-search"></i></button>
			    <?php echo Form::close(); ?>	
			</div>

		</div>

	</div>
	<section class="page-content jobs">

		<div class="wrap row">
			<?php if(Request::url() == url('/jobs')): ?>
				<div class="section-title">
					
				<h3>All Jobs</h3>  
				</div>
			<?php else: ?>
				<?php if(isset($company) && $company != 'search'): ?>
				<div class="section-title">
					
				<h3>Jobs of <?php echo e($company->name); ?></h3>
				</div>
			<?php else: ?>
				<div class="section-title">
					
				<h3>Search Results</h3>
				</div>
			<?php endif; ?>

			<?php endif; ?>


		    <div class="section-content">
		    	<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		        <ul class="lists row">

					<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
					<?php if($job->company): ?>
						<li class="wow fadeInUp">
			              <div class="wrap row">
			                <div class="img-wrap">
			                <?php if($job->company !== null): ?>
			                  <img src="<?php echo e(asset('image/job/'.$job->image)); ?>" alt="">
			                <?php endif; ?>
			                </div>
			                <div class="text-wrap">
			                  <h5><?php echo e($job->title); ?></h5>
			                  <div class="row">
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i><?php echo e($job->country); ?></div>
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Salary:<?php echo e($job->salary); ?></div>
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Required Number:<?php echo e($job->quantity); ?></div>
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i><?php echo e($job->facilities); ?></div>
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Cost:<?php echo e($job->cost); ?></div>
			                    <div class="s6 m4 col"><i class="fa fa-globe"></i>Duty Hour:<?php echo e($job->duty_hours); ?></div>
			                  </div>
			                  <div class="row">
			                    <p class="social">
			                      Share on <a href="#"><i class="ti-facebook"></i></a> <a href="#"><i class="ti-twitter"></i></a> <a href="#"><i class="ti-googleplus"></i></a>
			                    </p>
			                  </div>
			                </div>
			                <div class="btn-wrap">
			                  <a class="btn waves-effect" href="#<?php echo e($job->id); ?>">Apply Now</a><br>
			                  <a href="<?php echo e(url('company/'.$job->company->slug.'/job/'.$job->slug)); ?>">More info</a>
			                </div>
			              </div>
			            </li>
			            <div id="<?php echo e($job->id); ?>" class="modal">
			                <div class="modal-content">
			                  <h3>Apply for <?php echo e($job->title); ?></h3>
			                  <?php echo Form::open([
			                    'action' => ['\App\Http\Controllers\ApplicationController@store',$job->id],
			                     'method'=>'post','files' => true]); ?>

			                      <input type="text" name="full_name" placeholder="Full Name">
			                      <input type="text"  name="email" placeholder="email">
			                      <input type="text" name="contact" placeholder="Contact number">
			                      <input type="text" value = "job" name="apply" hidden>
			                      <div class="file-field input-field">
			                        <div class="btn">
			                          <span>Upload CV</span>
			                          <input type="file" name="cv">
			                        </div>
			                      </div>
			                      <button type="submit" class="btn" >Apply</button>
			                    <?php echo Form::close(); ?>

			                </div>
			            </div>
			         <?php endif; ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</ul>
				<?php echo $jobs->links(); ?>

			</div>
		</div>
	</section>
	</div>
</div>
<?php $__env->stopSection(); ?>

		
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>