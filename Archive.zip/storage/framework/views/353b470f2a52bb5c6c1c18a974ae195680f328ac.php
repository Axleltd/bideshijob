<?php $__env->startSection('content'); ?>

    <h1>Create New <?php echo e($route); ?></h1>
    <hr/>

    <?php echo Form::open( ['route' => config('watchtower.route.as') . $route .'.store', 'class' => 'form-horizontal']); ?>

    
    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
        <?php echo Form::label('name', 'Name: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
        <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

        </div>
        <?php echo $errors->first('name', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>

    <div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
        <?php echo Form::label('slug', 'Slug: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::text('slug', null, ['class' => 'form-control']); ?>

        </div>
        <?php echo $errors->first('slug', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>

    <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
        <?php echo Form::label('description', 'Description: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        </div>
        <?php echo $errors->first('description', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>

    <?php if($route == "role"): ?>
    <div class="form-group">
        <?php echo Form::label('special', 'Special Access: ', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <?php echo Form::select('special', array('all-access' => 'All Access', 'no-access' => 'No Access'), null, ['placeholder' => 'No special access.', 'class' => 'form-control'] ); ?>

        </div>
        <?php echo $errors->first('special', '<div class="col-sm-6 col-sm-offset-3 text-danger">:message</div>'); ?>

    </div>
    <?php endif; ?>

    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
            <?php echo Form::submit('Create '.$route, ['class' => 'btn btn-primary form-control']); ?>

        </div>    
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('watchtower.views.layouts.master'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>