<div class="row">
	<div class="col s12">
		<?php echo Form::label('name','name:'); ?>

		<?php echo Form::text('name',null); ?>

	</div>
	<div class="col s12">
		<?php echo Form::label('email','email: '); ?>

		<?php echo Form::text('email',null); ?>

	</div>
	<div class="col s12">
		<?php echo Form::label('message','message: '); ?>

		<?php echo Form::textarea('message',null); ?>

	</div>
	
</div>
	