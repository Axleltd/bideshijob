<div class="message">
	<div class="row">
		<div class="col m6 s12">
			<?php echo Form::label('name','name:'); ?>

			<?php echo Form::text('name',null); ?>

		</div>
		<div class="col m6 s12">
			<?php echo Form::label('email','email: '); ?>

			<?php echo Form::text('email',null); ?>

		</div>
		<div class="col m6 s12">
			<?php echo Form::label('message','message: '); ?>

			<?php echo Form::textarea('message',null); ?>

		</div>
		
	</div>
	
</div>