<?php $__env->startSection('title'); ?>
	Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
		
	<div class="section-title">
		<h3>All Company</h3>
		<ul class="bread-crumb">			
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="#">My Company</a></li>/			

		</ul>
	</div>

	<div class="section-content">

		<div class="row">

			<?php if(!count($companies)>0): ?>
					<h5>You have not created a company yet!</h5>
					<a class="btn" href="<?php echo e(url('/company/create')); ?>">Create A Company</a>
			<?php else: ?>
				<ul>
					<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						
						<li class="col s12 m4">
							<div class="card">
								<div class="card-image">   
									<img src="<?php echo e(asset('image/'.$company->logo)); ?>" alt="">
								</div>
									
								
									<span class="card-title"><a href="<?php echo e(url('/company/'.$company->slug)); ?>"><?php echo e($company->name); ?></a> <i class="material-icons activator right">more_vert</i></span>
									<div class="row">
										<p>
											Status: 
											<?php if($company->status): ?>
												Active
											<?php else: ?>
												Inactive
											<?php endif; ?>
										</p>
									</div>

							    <div class="card-reveal">
							      	<span class="card-title grey-text text-darken-4">More Options<i class="material-icons right">close</i></span>
							      	<a href="<?php echo e(url('/company/'.$company->slug.'/job/create')); ?>" class="btn">Create job</a>
									<a href="<?php echo e(url('/company/'.$company->slug.'/training/create')); ?>" class="btn">Create training</a>
							    </div>
							</div>
						</li>
				
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</ul>
			<?php endif; ?>
		</div>		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>