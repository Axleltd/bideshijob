<div class="form">
	<div class="row">
		<div class="col s12 m6 input-field">
			<?php echo Form::label('name','Name'); ?>	
			<?php echo Form::text('name',old('name')); ?>	
			<?php if(count($errors->get('name')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="col s12 m6 input-field">
			<?php echo Form::label('order','Order :'); ?>	
			<?php echo Form::number('order',old('order')); ?>	
			<?php if(count($errors->get('order')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		<div class="input-field">
		    <?php echo Form::label('image', 'Image:', ['class' => 'control-label']); ?>

		    <?php if(isset($category->image)): ?>
		        <div class="col-xs-2 thumb">
		            <a class="image" href="#">
		                <img class="img-responsive" src="<?php echo e(asset('image/'.$post->image)); ?>"
		                     alt="<?php echo e($post->title); ?>" id="output">
		            </a>
		        </div>
		    <?php else: ?>
		        <div class="controls">
		        	<img src="<?php echo e(asset('image/no-image.png')); ?>" alt="" id="output" width="300" height="300">
		        </div>
		    <?php endif; ?>

		        <?php echo Form::file('image', array('onchange'=>'loadFile(event)','id'=>'image')); ?>

		        <?php if(count($errors->get('image')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		

		</div>
		<div class="col s12 m6 input-field">
			
			<input type="checkbox" class="filled-in" id="filled-in-box"  name="featured" />
             <label for="filled-in-box">Featured</label>	
			<?php if(count($errors->get('featured')) > 0): ?>
		        <div class="alert alert-danger">
		            <ul>
		                <?php $__currentLoopData = $errors->get('featured'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                    <li><?php echo e($error); ?></li>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            </ul>
		        </div>
		    <?php endif; ?>		
		</div>
		
	</div>
</div>

<?php $__env->startPush('script'); ?>
	<script type="text/javascript">
	  $('.datepicker').pickadate({
	    selectMonths: true, // Creates a dropdown to control month
	    selectYears: 15 // Creates a dropdown of 15 years to control year
	  });
	</script>
<?php $__env->stopPush(); ?>
<script>	
  	var loadFile = function(event) {
    var reader = new FileReader();
    var fil=0;

    reader.onload = function(){
    	    		
    		var output = document.getElementById('output');
    		 output.src = reader.result;

    };
    reader.readAsDataURL(event.target.files[0]);
  	};
 </script>
