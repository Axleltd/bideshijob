<?php $__env->startSection('content'); ?>


	<div class="section-title">
		<h3>Add a Job</h3>
		<ul class="bread-crumb">
			<li><a href="/profile">Dashboard</a></li>/
			<li><a href="/profile/company"><?php echo e($company->name); ?></a></li>/
			<li><a href="#">Create Job</a></li>

		</ul>
	</div>

	<div class="section-content">
		<h5>Job Details</h5>

		<div class="row">
			 <?php echo Form::open([
		        'action' => ['\App\Http\Controllers\JobsController@store',$id],
		        'method'=>'post','files' => true]); ?>

				<?php echo $__env->make('job._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<button type="submit" class="waves-effect waves-light btn">Continue</button>
			<?php echo Form::close(); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>