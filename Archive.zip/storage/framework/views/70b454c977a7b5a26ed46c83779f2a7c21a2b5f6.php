<?php $__env->startSection('content'); ?>



	<div class="section-title">
		<h3>Add a Post</h3>
		<ul class="bread-crumb">
			<li><a href="">Dashboard</a></li>/
			<li><a href="">Company Name</a></li>/
			<li><a href="#">Create Post</a></li>

		</ul>
	</div>

	<div class="section-content">
		<h5>Post Details</h5>

		<div class="row">
			 <?php echo Form::open([
		                'action' => '\App\Http\Controllers\PostsController@store',
		                 'method'=>'post','files' => true]); ?>

				<?php echo $__env->make('post._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>				
				
				<button type="submit" class="waves-effect waves-light btn">Continue</button>
			<?php echo Form::close(); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>