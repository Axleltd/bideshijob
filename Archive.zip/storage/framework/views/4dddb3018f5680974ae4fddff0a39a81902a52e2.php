<?php $__env->startSection('title'); ?>
Contact-Us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 


<div class="page-inside page-contact">
	<div class="banner">
    	<div class="wrap">
        	<h3>Contact Us</h3>
		</div>

	</div>
	<section class="page-content contact_us">
		<?php echo $__env->make('admin._flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="wrap row">
			<div class="col s12 m6 form">

				<?php echo Form::open([
		        'method'=>'post','files' => true]); ?>

					<?php echo $__env->make('frontend._msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<button type="submit" class="waves-effect waves-light btn"> Send</button>
				<?php echo Form::close(); ?>

			</div>
			<div class="col s12 m6 info">
				<h4>Bideshi Kaam</h4>
				<p><i class="fa fa-map"></i> Address: Sanepa, Lalitput Nepal</p>
				<p><i class="fa fa-phone"></i> Contact Number: <a href="#">8946513215</a>, <a href="#">8946513215</a></p>
				<p><i class="fa fa-envelope"></i> Email: <a href="#">info@bideshikaam.com</a></p>
			</div>
		</div>
		<section class="map">
			<div id="map" style="height: 50vh; width: 100vw;"></div>
		</section>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBvDQqg3zszpBHiw5B8gEMhfBFMt3h_ZPE&callback=initMap"
    async defer></script>

    <script>
      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 8
        });
      }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>