<?php $__env->startSection('title'); ?>
Contact-Us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>Contact Us</h1>	
	
	 <?php echo Form::open([
        'method'=>'post','files' => true]); ?>

		<?php echo $__env->make('frontend._msg', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<button type="submit" class="waves-effect waves-light btn">Continue</button>
	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>