<div class="form">
	<div class="row">
		<div class="col s12 m12">
			<?php echo Form::label('question','question:'); ?>	
			<?php echo Form::text('question',old('question')); ?>	
		</div>

		<div class="col s12 m12">
			<?php echo Form::label('answer','Answer:'); ?>

			<?php echo Form::textarea('answer',old('answer')); ?>

		</div>
		<div class="col s12 m12">
			
			<div class="input-field col s12">
				<select name="status">
				  <option value="0" disabled selected>Choose your status</option>
				  <option value="1">Active</option>
				  <option value="0">Suspend</option>				  
				</select>				
			</div>	
		</div>

		<div class="col s12 m12">
			<?php echo Form::label('order','order:'); ?>

			<?php echo Form::number('order',old('order')); ?>

		</div>
	</div>
</div>