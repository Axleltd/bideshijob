<?php $__env->startSection('content'); ?>

<div class="application">
	<table>
        <thead>
          <tr>
              <th data-field="id">Name</th>
              <th data-field="name">Email</th>
              <th data-field="price">Message</th>
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			
			<tr>
				<td><?php echo e($message->name); ?></td>
				<td><?php echo e($message->email); ?></td>
				<td><?php echo e($message->messages); ?></td>
			</tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          <?php echo $messages->links(); ?>

        </tbody>
      </table>	
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>