<?php $__env->startSection('title'); ?>
	Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="section-title">
		<div class="row">
			<h3 class="left">Profile</h3>
			<div class="right">
				<?php if(!(count($profile)>0)): ?>
				
					<a  class="btn" href="<?php echo e(url('/profile/user/create')); ?>">Create Profile</a>
				
				<?php endif; ?>
			</div>
		</div>
		<ul class="bread-crumb">
			<li><a href="">Dashboard</a></li>/
			<li><a href="">Profile</a></li>/
		</ul>
	</div>

	<div class="section-content">

		<div class="row">

			<div class="form">
				 <?php echo Form::model($profile, ['action'=>['\App\Http\Controllers\ProfileController@update',$profile->id],'method'=>'PUT','files' => true]); ?>

					<?php echo $__env->make('admin.user._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<button type="submit" class="waves-effect waves-light btn">Update</button>
				<?php echo Form::close(); ?>


			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>