<?php

return [
	'home' => 'Home',
	'about' => 'About',
	'jobs' => 'Jobs',
	'profile' => 'Profile',
	'training' => 'Training',
	'agencies' => 'Agencies',
	'contact' => 'Contact',
	'faq' => 'FAQ',
	'dashboard' => 'Dashboard',
	'logout' => 'Logout',
	'login' => 'Login',
	'register' => 'Register',
	'english' => 'English',
	'nepali' => 'Nepali',

	'blog'  => 'Blog',

	//footer
	'city_address' => 'City Address',
	'country' =>'Country'

];