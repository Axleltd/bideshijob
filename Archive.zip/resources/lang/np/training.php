<?php 

return [
	'all' => 'Sab तलिम',
	'search_results' => 'Khoji result'
];