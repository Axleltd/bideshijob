<?php

return [
	//Titile 
	'home' => 'घर',
	'about' => 'हाम्रो बारेमा',
	'jobs' => 'काम',
	'profile' => 'Profile',
	'training' => 'तलिम',
	'agencies' => 'कार्यालय',
	'contact' => 'सम्पर्क',
	'faq' => 'प्रश्नहरु',
	'dashboard' => 'ड्यासबोर्ड',
	'logout' => 'Logout',
	'login' => 'Login',
	'register' => 'नयाँ सदस्य',
	'english' => 'अङ्ग्रेजि',
	'nepali' => 'नेपाली',

	'blog'  => 'BaLaog',
	
	//footer
	'city_address' =>'',
	'country' => 'राष्ट्र',

];