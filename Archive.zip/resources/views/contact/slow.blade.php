@extends('layouts.app')

@section('title')
	Contact Details
@stop

@section('content')
	<div class="col s12 m12">
		show contact
	</div>
@stop