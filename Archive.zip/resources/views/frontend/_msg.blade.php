<div class="row">
	<div class="col s12">
		{!! Form::label('name','name:') !!}
		{!! Form::text('name',null)  !!}
	</div>
	<div class="col s12">
		{!! Form::label('email','email: ') !!}
		{!! Form::text('email',null) !!}
	</div>
	<div class="col s12">
		{!! Form::label('message','message: ') !!}
		{!! Form::textarea('message',null) !!}
	</div>
	
</div>
	