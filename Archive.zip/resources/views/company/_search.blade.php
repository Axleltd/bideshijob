<input type="text" class="title" name="company" placeholder="Job / Training">
 <input type="text" class="location" name="country" placeholder="country">
